import "./App.css";
import Layout from "./shared/layout";
import Homepage from "./pages/home";
function App() {
  return (
    <div className="App">
      <Layout />
      <Homepage />
    </div>
  );
}

export default App;
