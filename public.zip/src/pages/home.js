import HeroSection from "../components/heroSection";
import ExplorePlatfrom from "../components/explorePlatform";
import LearnMoreCards from "../components/learnMoreCards";
import Features from "../components/features";
import FeaturesSection from "../components/customizeableSolutions";
const Homepage = () => {
  return (
    <>
      <HeroSection />
      <ExplorePlatfrom />
      <LearnMoreCards />
      <Features />
      <FeaturesSection/>
    </>
  );
};
export default Homepage;
